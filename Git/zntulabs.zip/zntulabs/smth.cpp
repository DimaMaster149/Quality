#include "smth.h"

Smth::Smth()
{

}
//asdasd
