#ifndef SMTH_H
#define SMTH_H


class Smth
{
public:
    Smth();
};

#endif // SMTH_H